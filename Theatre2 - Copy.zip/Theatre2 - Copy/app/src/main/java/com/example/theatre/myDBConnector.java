package com.example.theatre;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import java.util.ArrayList;

public class myDBConnector extends SQLiteOpenHelper {
    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "Registration.db";
    private static final String TABLE_NAME = "Registration_details";
    private static final String COLUMN_NAME = "Name";
    private static final String COLUMN_USERNAME = "Username";
    private static final String COLUMN_PASSWORD = "Password";


    public myDBConnector(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(" +
                COLUMN_NAME + " STRING, " +
                COLUMN_USERNAME + " STRING, " +
                COLUMN_PASSWORD + " STRING " + ")");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public void addNewUser(String name, String userName, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_USERNAME, userName);
        values.put(COLUMN_PASSWORD, password);


        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public ArrayList<newuserlist> check_List() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" SELECT * FROM " + TABLE_NAME, null);
        ArrayList<newuserlist> arrayList = new ArrayList<>();
        while (cursor.moveToNext()) {
            newuserlist contact = new newuserlist();
            contact.username = cursor.getString(0);
            contact.password = cursor.getString(1);
            arrayList.add(contact);
        }
        for (newuserlist d : arrayList) {
            System.out.println(d.getName());
        }
        return arrayList;
    }

    public boolean checkLogin(String username, String password) {
        return false;
    }
}

