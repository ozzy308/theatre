package com.example.theatre;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.activity_theatre.xml.R;

public class Register extends AppCompatActivity {

    EditText name;
    EditText username;
    EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        name = findViewById(R.id.Name);
        username = findViewById(R.id.Username);
        password = findViewById(R.id.Password);
    }
        public void database (View view){
        myDBConnector registerDBC = new myDBConnector(this);
            String nme = String.valueOf(name.getText());
            String usrnme = String.valueOf(username.getText());
            String psswrd = String.valueOf(password.getText());

            if(registerDBC.checkLogin(usrnme, psswrd) == true) {
                Toast.makeText(getApplicationContext(), "This username already exists", Toast.LENGTH_SHORT).show();
            }else {
                registerDBC.addNewUser(nme, usrnme, psswrd);
                name.setText("");
                username.setText("");
                password.setText("");
                Toast.makeText(getApplicationContext(),"Registration was successful", Toast.LENGTH_LONG).show();
            }

        }
    public void Register(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}