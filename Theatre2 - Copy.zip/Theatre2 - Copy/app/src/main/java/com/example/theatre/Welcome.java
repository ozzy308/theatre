package com.example.theatre;

import androidx.appcompat.app.AppCompatActivity;

public class Welcome extends AppCompatActivity {
}
