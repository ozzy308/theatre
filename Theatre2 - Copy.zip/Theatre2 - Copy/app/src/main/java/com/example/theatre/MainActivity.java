package com.example.theatre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.activity_theatre.xml.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText username;
    EditText password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.usernameTxt);
        password = findViewById(R.id.passwordTxt);
        myDBConnector db = new myDBConnector(this);
        ArrayList<newuserlist>newdetails = db.check_List();
        for(newuserlist detail1:newdetails){
            System.out.println(detail1.getName());
        }
    }

    public void register(View v) {
        Intent intent = new Intent(this, Register.class);
        startActivity(intent);
    }

    public void check(View v) {
        String Username = String.valueOf(username.getText());
        String Password = String.valueOf(password.getText());
        myDBConnector registerDBC = new myDBConnector(this);
        if (registerDBC.checkLogin(Username, Password) == true) {
            Intent intent = new Intent(this, theatre.class);
            startActivity(intent);
        } else if (registerDBC.checkLogin(Username, Password) == false) {
            Toast.makeText(getApplicationContext(), "Login unsuccessful", Toast.LENGTH_LONG).show();
            username.setText("");
            password.setText("");
        }
    }
}

