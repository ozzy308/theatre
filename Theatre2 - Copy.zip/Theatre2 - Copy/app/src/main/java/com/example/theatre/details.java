package com.example.theatre;

public class details {
    String title;
    String description;
    Integer time;
    String date;
    Boolean wheelchairAccess;
    Boolean epilepsy;
    public String getTitle() {
        return title;
    }
    public String getDescription() {
        return description;
    }
    public String getDate() {
        return date;
    }
    public int getTime() {
        return time;
    }

    public void setTitle(String title){
        this.title = title;
    }
    public void setDescription(String description){
        this.description = description;
    }
    public void setDate(String date){
        this.date = date;
    }
    public void setTime(Integer time){
        this.time = time;
    }

    public boolean getWheelchairAccess() {
        return wheelchairAccess;
    }

    public boolean getEpilepsy() {
        return epilepsy;
    }
    details(String Title, String Description, String Date,int Time, boolean WheelChairAccess, boolean Epilepsy) {
        title = Title;
        description = Description;
        date = Date;
        time = Time;
        wheelchairAccess = WheelChairAccess;
        epilepsy = Epilepsy;
    }

}


